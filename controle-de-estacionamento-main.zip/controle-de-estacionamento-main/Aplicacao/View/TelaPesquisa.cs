﻿using Aplicacao.Controller;
using Aplicacao.Model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Aplicacao.View
{
    public partial class TelaPesquisa : Form
    {
        public TelaPesquisa()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string placa = (txtPlacaLetras.Text.ToString() + "-" + txtPlacaNumeros.Text.ToString());
            List<Cliente> clientes = ClienteController.PesquisarVeiculo(placa);
            dgvPesquisa.DataSource = clientes;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
