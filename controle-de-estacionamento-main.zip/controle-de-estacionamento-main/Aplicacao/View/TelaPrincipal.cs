﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aplicacao.Controller;
using Aplicacao.Model;
using Microsoft.Data.Sqlite;
namespace Aplicacao.View
{
    public partial class TelaPrincipal : Form
    {
        public TelaPrincipal()
        {
            InitializeComponent();

            // Criar método para atualizar automaticamente
            List<Cliente> clientes = ClienteController.ListarClientesEstacionados();
            dgvEstacionamento.DataSource = clientes;

            timerDataHora.Enabled = true;
            timerDataHora.Interval = 1000;
        }

        private void btnPesquisa_Click(object sender, EventArgs e)
        {
            var telaPesquisa = new TelaPesquisa();
            telaPesquisa.ShowDialog();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            var telaEntrada = new TelaEntrada();
            telaEntrada.ShowDialog();
        }

        private void btnSaida_Click(object sender, EventArgs e)
        {
            var telaSaida = new TelaSaida();
            telaSaida.ShowDialog();
        }

        private void timerDataHora_Tick(object sender, EventArgs e)
        {
            lblDataHora.Text = (DateTime.Now.ToString("F"));
        }
    }
}
