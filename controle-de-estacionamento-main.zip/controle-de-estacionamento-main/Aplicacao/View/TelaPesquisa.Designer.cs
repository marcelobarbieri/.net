﻿namespace Aplicacao.View
{
    partial class TelaPesquisa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTexto = new System.Windows.Forms.Label();
            this.txtPlacaLetras = new System.Windows.Forms.TextBox();
            this.lblSeparadorPlaca = new System.Windows.Forms.Label();
            this.txtPlacaNumeros = new System.Windows.Forms.TextBox();
            this.lblImagemPlaca = new System.Windows.Forms.Label();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.dgvPesquisa = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPesquisa)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTexto.Location = new System.Drawing.Point(12, 23);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(266, 37);
            this.lblTexto.TabIndex = 0;
            this.lblTexto.Text = "INFORME A PLACA:";
            // 
            // txtPlacaLetras
            // 
            this.txtPlacaLetras.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPlacaLetras.Location = new System.Drawing.Point(44, 74);
            this.txtPlacaLetras.MaxLength = 3;
            this.txtPlacaLetras.Name = "txtPlacaLetras";
            this.txtPlacaLetras.Size = new System.Drawing.Size(73, 43);
            this.txtPlacaLetras.TabIndex = 1;
            // 
            // lblSeparadorPlaca
            // 
            this.lblSeparadorPlaca.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSeparadorPlaca.Location = new System.Drawing.Point(123, 65);
            this.lblSeparadorPlaca.Name = "lblSeparadorPlaca";
            this.lblSeparadorPlaca.Size = new System.Drawing.Size(34, 55);
            this.lblSeparadorPlaca.TabIndex = 2;
            this.lblSeparadorPlaca.Text = "-";
            this.lblSeparadorPlaca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacaNumeros
            // 
            this.txtPlacaNumeros.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPlacaNumeros.Location = new System.Drawing.Point(156, 74);
            this.txtPlacaNumeros.MaxLength = 4;
            this.txtPlacaNumeros.Name = "txtPlacaNumeros";
            this.txtPlacaNumeros.Size = new System.Drawing.Size(80, 43);
            this.txtPlacaNumeros.TabIndex = 3;
            // 
            // lblImagemPlaca
            // 
            this.lblImagemPlaca.Image = global::Aplicacao.Properties.Resources.Placa;
            this.lblImagemPlaca.Location = new System.Drawing.Point(452, 23);
            this.lblImagemPlaca.Name = "lblImagemPlaca";
            this.lblImagemPlaca.Size = new System.Drawing.Size(229, 90);
            this.lblImagemPlaca.TabIndex = 4;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPesquisar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnPesquisar.Location = new System.Drawing.Point(66, 150);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(150, 50);
            this.btnPesquisar.TabIndex = 5;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCancelar.Location = new System.Drawing.Point(66, 267);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(150, 50);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // dgvPesquisa
            // 
            this.dgvPesquisa.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPesquisa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPesquisa.Location = new System.Drawing.Point(321, 150);
            this.dgvPesquisa.Name = "dgvPesquisa";
            this.dgvPesquisa.RowTemplate.Height = 25;
            this.dgvPesquisa.Size = new System.Drawing.Size(486, 177);
            this.dgvPesquisa.TabIndex = 7;
            // 
            // TelaPesquisa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 339);
            this.Controls.Add(this.dgvPesquisa);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.lblImagemPlaca);
            this.Controls.Add(this.txtPlacaNumeros);
            this.Controls.Add(this.lblSeparadorPlaca);
            this.Controls.Add(this.txtPlacaLetras);
            this.Controls.Add(this.lblTexto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TelaPesquisa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pesquisar Veículo";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPesquisa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.TextBox txtPlacaLetras;
        private System.Windows.Forms.Label lblSeparadorPlaca;
        private System.Windows.Forms.TextBox txtPlacaNumeros;
        private System.Windows.Forms.Label lblImagemPlaca;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.DataGridView dgvPesquisa;
    }
}