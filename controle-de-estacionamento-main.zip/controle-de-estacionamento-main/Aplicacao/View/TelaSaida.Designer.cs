﻿namespace Aplicacao.View
{
    partial class TelaSaida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnSaida = new System.Windows.Forms.Button();
            this.txtPlacaNumeros = new System.Windows.Forms.TextBox();
            this.lblSeparadorPlaca = new System.Windows.Forms.Label();
            this.txtPlacaLetras = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblImagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancelar
            // 
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCancelar.Location = new System.Drawing.Point(71, 462);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(150, 50);
            this.btnCancelar.TabIndex = 9;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSaida
            // 
            this.btnSaida.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSaida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSaida.Location = new System.Drawing.Point(34, 347);
            this.btnSaida.Name = "btnSaida";
            this.btnSaida.Size = new System.Drawing.Size(227, 50);
            this.btnSaida.TabIndex = 10;
            this.btnSaida.Text = "Marcar Saída";
            this.btnSaida.UseVisualStyleBackColor = true;
            this.btnSaida.Click += new System.EventHandler(this.btnSaida_Click);
            // 
            // txtPlacaNumeros
            // 
            this.txtPlacaNumeros.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPlacaNumeros.Location = new System.Drawing.Point(156, 254);
            this.txtPlacaNumeros.MaxLength = 4;
            this.txtPlacaNumeros.Name = "txtPlacaNumeros";
            this.txtPlacaNumeros.Size = new System.Drawing.Size(80, 43);
            this.txtPlacaNumeros.TabIndex = 15;
            // 
            // lblSeparadorPlaca
            // 
            this.lblSeparadorPlaca.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSeparadorPlaca.Location = new System.Drawing.Point(123, 245);
            this.lblSeparadorPlaca.Name = "lblSeparadorPlaca";
            this.lblSeparadorPlaca.Size = new System.Drawing.Size(34, 55);
            this.lblSeparadorPlaca.TabIndex = 14;
            this.lblSeparadorPlaca.Text = "-";
            this.lblSeparadorPlaca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacaLetras
            // 
            this.txtPlacaLetras.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPlacaLetras.Location = new System.Drawing.Point(44, 254);
            this.txtPlacaLetras.MaxLength = 3;
            this.txtPlacaLetras.Name = "txtPlacaLetras";
            this.txtPlacaLetras.Size = new System.Drawing.Size(73, 43);
            this.txtPlacaLetras.TabIndex = 13;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTexto.Location = new System.Drawing.Point(12, 203);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(266, 37);
            this.lblTexto.TabIndex = 12;
            this.lblTexto.Text = "INFORME A PLACA:";
            // 
            // lblImagem
            // 
            this.lblImagem.Image = global::Aplicacao.Properties.Resources.Logo;
            this.lblImagem.Location = new System.Drawing.Point(12, 9);
            this.lblImagem.Name = "lblImagem";
            this.lblImagem.Size = new System.Drawing.Size(274, 177);
            this.lblImagem.TabIndex = 11;
            // 
            // TelaSaida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 524);
            this.Controls.Add(this.txtPlacaNumeros);
            this.Controls.Add(this.lblSeparadorPlaca);
            this.Controls.Add(this.txtPlacaLetras);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblImagem);
            this.Controls.Add(this.btnSaida);
            this.Controls.Add(this.btnCancelar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TelaSaida";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Marcar Saída";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnSaida;
        private System.Windows.Forms.TextBox txtPlacaNumeros;
        private System.Windows.Forms.Label lblSeparadorPlaca;
        private System.Windows.Forms.TextBox txtPlacaLetras;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblImagem;
    }
}