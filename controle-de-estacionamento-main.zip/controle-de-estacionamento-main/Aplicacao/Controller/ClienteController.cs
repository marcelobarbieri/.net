﻿using System;
using System.Collections.Generic;
using System.Data;
using Aplicacao.Model;
using Aplicacao.View;
using Dapper;
using Microsoft.Data.Sqlite;

namespace Aplicacao.Controller
{
    internal static class ClienteController
    {
        public static void MarcarEntrada(string placa)
        {
            string connectionString = "Data Source = estacionamento.db";

            var cliente = new Cliente(placa);

            var insertQuery = @"INSERT INTO [Clientes]
                                    VALUES (
                                            @Id,
                                            @Placa,
                                            @HoraEntrada,
                                            @HoraSaida,
                                            @Estacionado
                                            )";

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Execute(insertQuery, new
                {
                    Id = cliente.Id,
                    Placa = cliente.Placa,
                    HoraEntrada = DateTime.Now,
                    HoraSaida = cliente.HoraSaida,
                    Estacionado = true
                });
            }
        }

        public static void MarcarSaida(string placa)
        {
            string connectionString = "Data Source = estacionamento.db";

            var cliente = new Cliente(placa);

            var updateQuery = @"UPDATE [Clientes]
                                SET [HoraSaida] = @HoraSaida,
                                    [Estacionado] = @Estacionado
                                WHERE [Placa] = @Placa";

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Execute(updateQuery, new
                {
                    Placa = placa,
                    HoraSaida = DateTime.Now,
                    Estacionado = false
                });
            }
        }

        public static List<Cliente> PesquisarVeiculo(string placa)
        {
            string connectionString = "Data Source = estacionamento.db";

            var selectQuery = @"SELECT * FROM 
                                    [Clientes]
                                WHERE
                                    [Placa] = @Placa";

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                connection.Execute(selectQuery, new
                {
                    Placa = placa
                });

                var query = $"SELECT * FROM [Clientes] WHERE [Placa] = '{placa}'";

                SqliteCommand command = new SqliteCommand(query, connection);
                SqliteDataReader reader = command.ExecuteReader();
                var clientes = new List<Cliente>();
                while (reader.Read())
                {
                    var cliente = new Cliente
                    {
                        // Id = Convert.ToInt32(reader["Id"]),
                        Placa = reader["Placa"].ToString(),
                        HoraEntrada = Convert.ToDateTime(reader["HoraEntrada"]),
                        HoraSaida = Convert.ToDateTime(reader["HoraSaida"]),
                        Estacionado = Convert.ToBoolean(reader["Estacionado"])
                    };
                    clientes.Add(cliente);
                }
                return clientes;
            }
        }

        public static List<Cliente> ListarClientesEstacionados()
        {
            string connectionString = "Data Source = estacionamento.db";

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();

                var query = "SELECT * FROM [Clientes] WHERE [Estacionado] = '1'";

                SqliteCommand command = new SqliteCommand(query, connection);
                SqliteDataReader reader = command.ExecuteReader();
                var clientes = new List<Cliente>();
                while (reader.Read())
                {
                    var cliente = new Cliente
                    {
                        Placa = reader["Placa"].ToString(),
                        HoraEntrada = Convert.ToDateTime(reader["HoraEntrada"]),
                        // HoraSaida = Convert.ToDateTime(reader["HoraSaida"]),
                        Estacionado = Convert.ToBoolean(reader["Estacionado"])
                    };
                    clientes.Add(cliente);
                }
                return clientes;
            }
        }
    }
}
