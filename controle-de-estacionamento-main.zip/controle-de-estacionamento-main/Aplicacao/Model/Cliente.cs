﻿using System;

namespace Aplicacao.Model
{
    internal class Cliente
    {
        public int? Id { get; set; }
        public string Placa { get; set; }
        public DateTime HoraEntrada { get; set; }
        public DateTime? HoraSaida { get; set; }
        public bool Estacionado { get; set; }

        public Cliente()
        {

        }

        public Cliente(string placa)
        {
            Placa = placa;
        }
    }
}
