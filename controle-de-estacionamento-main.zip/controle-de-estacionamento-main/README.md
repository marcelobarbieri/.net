# Controle de Estacionamento
Projeto de uma aplicação para controle de estacionamento com Windows Forms.

### Menú de Navegação :world_map:
- [TODO List](#warning-todo-warning)
- [Imagens](#imagens)
- [Tecnologias Utilizadas](#tecnologias-utilizadas)
- [Ferramentas Utilizadas](#ferramentas-utilizadas)

## :warning: TODO :warning:
- [ ] Corrigir e Personalizar DataGridViews

## Imagens
### Tela Principal
![TelaPrincipal](Imagens/TelaInicial.png)

### Tela Entrada
![TelaEntrada](Imagens/TelaEntrada.png)

### Tela Pesquisa
![TelaPesquisa](Imagens/TelaPesquisa.png)

## Tecnologias Utilizadas
- [x] C#
- [x] .NET
- [x] Windows Forms
- [x] SQL

## Ferramentas Utilizadas
- [x] Visual Studio Community 2022
- [x] SQLite Studio